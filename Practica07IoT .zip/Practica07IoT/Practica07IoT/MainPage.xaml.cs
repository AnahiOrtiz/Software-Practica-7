﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using OpenNETCF.MQTT;
using System.Threading;

namespace Practica07IoT
{
    public partial class MainPage : ContentPage
    {
        //Objeto MQTT
        MQTTClient mqtt;
        string mensaje = "";
        List<string> MensajeList = new List<string>();
        public MainPage()
        {
            InitializeComponent();
        }
        private void btnConectar_Clicked(object sender, EventArgs e)
        {
            //Validaciones del servidor y del puerto
            if (string.IsNullOrEmpty(txtServidor.Text))
            {
                DisplayAlert("Error", "No se ha ingresado el servidor", "OK");
            }
            if (string.IsNullOrEmpty(txtPuerto.Text))
            {
                DisplayAlert("Error", "No se ha ingresado el puerto", "OK");
            }
            int puerto = 0;
            if (!int.TryParse(txtPuerto.Text, out puerto))
            {
                DisplayAlert("Error", "El puerto ingresado no es un número", "OK");
            }
            mqtt = new MQTTClient(txtServidor.Text, puerto);
            mqtt.Connect(txtCliente.Text);
            while (!mqtt.IsConnected)
            {
                Thread.Sleep(1000);
            }
            DisplayAlert("Conectado", "Conexión exitosa", "Ok");
            mqtt.Connected += Mqtt_Connected;
            mqtt.MessageReceived += Mqtt_MessageReceived;
            Device.StartTimer(TimeSpan.FromMilliseconds(200), () => {
                if (mqtt.IsConnected)
                {
                    if (mensaje != "")
                    {
                        MensajeList.Add(mensaje);
                        lstMensajes.ItemsSource = null;
                        lstMensajes.ItemsSource = MensajeList;
                        mensaje = "";
                    }
                }
                return true;
            });  
        }
        private void Mqtt_MessageReceived(string topic, QoS qos, byte[] payload)
        {
            mensaje = $"[{topic}]:{Encoding.UTF8.GetString(payload)}";
        }

        private void Mqtt_Connected(object sender, EventArgs e)
        {
            DisplayAlert("Correcto", "Se ha conectado de forma exitosa", "Éxito");
        }
        private void btnSuscribirse_Clicked(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtTopico.Text))
            {
                DisplayAlert("Alerta", "No se ha ingresado nada en el tópico", "Ok");
            }
            if (mqtt.IsConnected)
            {
                mqtt.Subscriptions.Add(new Subscription(txtTopico.Text));
                DisplayAlert("Éxito", "Se ha suscrito al tópico", "Ok");
            }
            else
            {
                DisplayAlert("Error", "No se ha suscrito al tópico", "Ok");
            }
        }
        private void btnEnviar_Clicked(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtTopico.Text))
            {
                DisplayAlert("Alerta","No se ha suscrito al tópico","Ok");
            }
            if (string.IsNullOrEmpty(txtMensaje.Text))
            {
                DisplayAlert("Alerta", "No se ha ingresado el mensaje", "Ok");
            }
            if (mqtt.IsConnected)
            {
                mqtt.Publish(txtTopico.Text, Encoding.UTF8.GetBytes(txtMensaje.Text), QoS.FireAndForget, false);
                DisplayAlert("Éxito", "Mensaje enviado a "+txtTopico.Text, "Ok");
            }
            else
            {
                DisplayAlert("Alerta", "Servicio MQTT no conectado...", "Error");
            }
        }
    }
}